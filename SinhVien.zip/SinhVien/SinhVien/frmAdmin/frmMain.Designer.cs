﻿namespace SinhVien.frmAdmin
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMain));
            this.panelMenu = new System.Windows.Forms.Panel();
            this.btnDangXuat = new System.Windows.Forms.Button();
            this.btnQLSV = new System.Windows.Forms.Button();
            this.btnQLKyThi = new System.Windows.Forms.Button();
            this.btnQLMH = new System.Windows.Forms.Button();
            this.btnQLKetQua = new System.Windows.Forms.Button();
            this.btnQLDeThi = new System.Windows.Forms.Button();
            this.btnQLCH = new System.Windows.Forms.Button();
            this.btnTranChu = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.panelDesktop = new System.Windows.Forms.Panel();
            this.panelMenu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.SuspendLayout();
            // 
            // panelMenu
            // 
            this.panelMenu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(235)))), ((int)(((byte)(253)))));
            this.panelMenu.Controls.Add(this.btnDangXuat);
            this.panelMenu.Controls.Add(this.btnQLSV);
            this.panelMenu.Controls.Add(this.btnQLKyThi);
            this.panelMenu.Controls.Add(this.btnQLMH);
            this.panelMenu.Controls.Add(this.btnQLKetQua);
            this.panelMenu.Controls.Add(this.btnQLDeThi);
            this.panelMenu.Controls.Add(this.btnQLCH);
            this.panelMenu.Controls.Add(this.btnTranChu);
            this.panelMenu.Controls.Add(this.pictureBox2);
            this.panelMenu.Controls.Add(this.pictureBox1);
            this.panelMenu.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelMenu.Location = new System.Drawing.Point(0, 0);
            this.panelMenu.Name = "panelMenu";
            this.panelMenu.Size = new System.Drawing.Size(202, 761);
            this.panelMenu.TabIndex = 0;
            // 
            // btnDangXuat
            // 
            this.btnDangXuat.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnDangXuat.FlatAppearance.BorderSize = 0;
            this.btnDangXuat.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDangXuat.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDangXuat.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(142)))), ((int)(((byte)(239)))));
            this.btnDangXuat.Image = ((System.Drawing.Image)(resources.GetObject("btnDangXuat.Image")));
            this.btnDangXuat.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDangXuat.Location = new System.Drawing.Point(3, 722);
            this.btnDangXuat.Name = "btnDangXuat";
            this.btnDangXuat.Size = new System.Drawing.Size(196, 39);
            this.btnDangXuat.TabIndex = 2;
            this.btnDangXuat.Text = "Đăng Xuất";
            this.btnDangXuat.UseVisualStyleBackColor = true;
            this.btnDangXuat.Click += new System.EventHandler(this.btnDangXuat_Click);
            // 
            // btnQLSV
            // 
            this.btnQLSV.FlatAppearance.BorderSize = 0;
            this.btnQLSV.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnQLSV.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnQLSV.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(142)))), ((int)(((byte)(239)))));
            this.btnQLSV.Image = ((System.Drawing.Image)(resources.GetObject("btnQLSV.Image")));
            this.btnQLSV.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnQLSV.Location = new System.Drawing.Point(3, 422);
            this.btnQLSV.Name = "btnQLSV";
            this.btnQLSV.Size = new System.Drawing.Size(196, 39);
            this.btnQLSV.TabIndex = 2;
            this.btnQLSV.Text = "Quản Lý Sinh Viên";
            this.btnQLSV.UseVisualStyleBackColor = true;
            this.btnQLSV.Click += new System.EventHandler(this.btnQLSV_Click);
            // 
            // btnQLKyThi
            // 
            this.btnQLKyThi.FlatAppearance.BorderSize = 0;
            this.btnQLKyThi.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnQLKyThi.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnQLKyThi.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(142)))), ((int)(((byte)(239)))));
            this.btnQLKyThi.Image = ((System.Drawing.Image)(resources.GetObject("btnQLKyThi.Image")));
            this.btnQLKyThi.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnQLKyThi.Location = new System.Drawing.Point(3, 377);
            this.btnQLKyThi.Name = "btnQLKyThi";
            this.btnQLKyThi.Size = new System.Drawing.Size(196, 39);
            this.btnQLKyThi.TabIndex = 2;
            this.btnQLKyThi.Text = "Quản Lý Kỳ Thi";
            this.btnQLKyThi.UseVisualStyleBackColor = true;
            this.btnQLKyThi.Click += new System.EventHandler(this.btnQLKyThi_Click);
            // 
            // btnQLMH
            // 
            this.btnQLMH.FlatAppearance.BorderSize = 0;
            this.btnQLMH.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnQLMH.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnQLMH.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(142)))), ((int)(((byte)(239)))));
            this.btnQLMH.Image = ((System.Drawing.Image)(resources.GetObject("btnQLMH.Image")));
            this.btnQLMH.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnQLMH.Location = new System.Drawing.Point(3, 332);
            this.btnQLMH.Name = "btnQLMH";
            this.btnQLMH.Size = new System.Drawing.Size(196, 39);
            this.btnQLMH.TabIndex = 2;
            this.btnQLMH.Text = "Quản Lý Môn Học";
            this.btnQLMH.UseVisualStyleBackColor = true;
            this.btnQLMH.Click += new System.EventHandler(this.btnQLMH_Click);
            // 
            // btnQLKetQua
            // 
            this.btnQLKetQua.FlatAppearance.BorderSize = 0;
            this.btnQLKetQua.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnQLKetQua.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnQLKetQua.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(142)))), ((int)(((byte)(239)))));
            this.btnQLKetQua.Image = ((System.Drawing.Image)(resources.GetObject("btnQLKetQua.Image")));
            this.btnQLKetQua.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnQLKetQua.Location = new System.Drawing.Point(3, 287);
            this.btnQLKetQua.Name = "btnQLKetQua";
            this.btnQLKetQua.Size = new System.Drawing.Size(196, 39);
            this.btnQLKetQua.TabIndex = 2;
            this.btnQLKetQua.Text = "Quản Lý Kết Quả";
            this.btnQLKetQua.UseVisualStyleBackColor = true;
            this.btnQLKetQua.Click += new System.EventHandler(this.btnQLKetQua_Click);
            // 
            // btnQLDeThi
            // 
            this.btnQLDeThi.FlatAppearance.BorderSize = 0;
            this.btnQLDeThi.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnQLDeThi.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnQLDeThi.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(142)))), ((int)(((byte)(239)))));
            this.btnQLDeThi.Image = ((System.Drawing.Image)(resources.GetObject("btnQLDeThi.Image")));
            this.btnQLDeThi.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnQLDeThi.Location = new System.Drawing.Point(3, 242);
            this.btnQLDeThi.Name = "btnQLDeThi";
            this.btnQLDeThi.Size = new System.Drawing.Size(196, 39);
            this.btnQLDeThi.TabIndex = 2;
            this.btnQLDeThi.Text = "Quản Lý Đề Thi";
            this.btnQLDeThi.UseVisualStyleBackColor = true;
            this.btnQLDeThi.Click += new System.EventHandler(this.btnQLDeThi_Click);
            // 
            // btnQLCH
            // 
            this.btnQLCH.FlatAppearance.BorderSize = 0;
            this.btnQLCH.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnQLCH.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnQLCH.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(142)))), ((int)(((byte)(239)))));
            this.btnQLCH.Image = ((System.Drawing.Image)(resources.GetObject("btnQLCH.Image")));
            this.btnQLCH.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnQLCH.Location = new System.Drawing.Point(3, 197);
            this.btnQLCH.Name = "btnQLCH";
            this.btnQLCH.Size = new System.Drawing.Size(196, 39);
            this.btnQLCH.TabIndex = 2;
            this.btnQLCH.Text = "Quản Lý Câu Hỏi";
            this.btnQLCH.UseVisualStyleBackColor = true;
            this.btnQLCH.Click += new System.EventHandler(this.btnQLCH_Click);
            // 
            // btnTranChu
            // 
            this.btnTranChu.FlatAppearance.BorderSize = 0;
            this.btnTranChu.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTranChu.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTranChu.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(142)))), ((int)(((byte)(239)))));
            this.btnTranChu.Image = ((System.Drawing.Image)(resources.GetObject("btnTranChu.Image")));
            this.btnTranChu.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnTranChu.Location = new System.Drawing.Point(3, 152);
            this.btnTranChu.Name = "btnTranChu";
            this.btnTranChu.Size = new System.Drawing.Size(196, 39);
            this.btnTranChu.TabIndex = 2;
            this.btnTranChu.Text = "Trang Chủ";
            this.btnTranChu.UseVisualStyleBackColor = true;
            this.btnTranChu.Click += new System.EventHandler(this.btnTranChu_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(0, 91);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(202, 41);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 1;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(200, 90);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // panel1
            // 
            this.panel1.AccessibleRole = System.Windows.Forms.AccessibleRole.None;
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(142)))), ((int)(((byte)(239)))));
            this.panel1.Controls.Add(this.pictureBox5);
            this.panel1.Controls.Add(this.pictureBox4);
            this.panel1.Controls.Add(this.pictureBox3);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(202, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1032, 40);
            this.panel1.TabIndex = 1;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.pictureBox5.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox5.Image")));
            this.pictureBox5.Location = new System.Drawing.Point(968, 1);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(43, 39);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox5.TabIndex = 0;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(919, 1);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(43, 39);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox4.TabIndex = 0;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(870, 1);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(43, 39);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 0;
            this.pictureBox3.TabStop = false;
            // 
            // panelDesktop
            // 
            this.panelDesktop.BackColor = System.Drawing.Color.White;
            this.panelDesktop.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelDesktop.Location = new System.Drawing.Point(202, 40);
            this.panelDesktop.Name = "panelDesktop";
            this.panelDesktop.Size = new System.Drawing.Size(1032, 721);
            this.panelDesktop.TabIndex = 2;
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1234, 761);
            this.Controls.Add(this.panelDesktop);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panelMenu);
            this.Name = "frmMain";
            this.Text = "frmMain";
            this.panelMenu.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelMenu;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btnDangXuat;
        private System.Windows.Forms.Button btnQLSV;
        private System.Windows.Forms.Button btnQLKyThi;
        private System.Windows.Forms.Button btnQLMH;
        private System.Windows.Forms.Button btnQLKetQua;
        private System.Windows.Forms.Button btnQLDeThi;
        private System.Windows.Forms.Button btnQLCH;
        private System.Windows.Forms.Button btnTranChu;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Panel panelDesktop;
    }
}